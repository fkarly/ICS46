// proj2.hpp

#ifndef __PROJ_2_HPP
#define __PROJ_2_HPP

#include <map>
#include <iostream>

std::map<int, int> assignBusSeats(std::istream & in);

#endif 
