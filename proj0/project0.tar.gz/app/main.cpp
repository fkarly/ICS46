#include "proj0.hpp"
#include <iostream>

int main()
{
  return 0;
}
